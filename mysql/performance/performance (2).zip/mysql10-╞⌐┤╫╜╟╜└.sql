DROP TABLE IF EXISTS posts;
DROP TABLE IF EXISTS users;

CREATE TABLE users (
   id INT AUTO_INCREMENT PRIMARY KEY,
   name VARCHAR(50) NOT NULL,
   created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE posts (
   id INT AUTO_INCREMENT PRIMARY KEY,
   title VARCHAR(255) NOT NULL,
   created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
   user_id INT,
   FOREIGN KEY (user_id) REFERENCES users(id)
);


-- 더미데이터
set session cte_max_recursion_depth = 1000000;

-- users 테이블에 더미 데이터 삽입
insert into users (name, created_at)
with recursive cte (n) as
(
 select 1
 union all
 select n + 1 FROM cte WHERE n < 1000000 -- 생성하고 싶은 더미 데이터의 개수
)
select 
   CONCAT('User', LPAD(n, 7, '0')) AS name,  -- 'User' 다음에 7자리 숫자로 구성된 이름 생성
   TIMESTAMP(DATE_SUB(NOW(), INTERVAL FLOOR(RAND() * 3650) DAY) + INTERVAL FLOOR(RAND() * 86400) SECOND) AS created_at -- 최근 10년 내의 임의의 날짜와 시간 생성
from cte;

-- posts 테이블에 더미 데이터 삽입
insert into posts (title, created_at, user_id)
with recursive cte (n) as
(
 SELECT 1
 UNION ALL
 SELECT n + 1 FROM cte WHERE n < 1000000 -- 생성하고 싶은 더미 데이터의 개수
)
SELECT 
   CONCAT('Post', LPAD(n, 7, '0')) AS name,  -- 'User' 다음에 7자리 숫자로 구성된 이름 생성
   TIMESTAMP(DATE_SUB(NOW(), INTERVAL FLOOR(RAND() * 3650) DAY) + INTERVAL FLOOR(RAND() * 86400) SECOND) AS created_at, -- 최근 10년 내의 임의의 날짜와 시간 생성
   FLOOR(1 + RAND() * 50000) AS user_id -- 1부터 50000 사이의 난수로 급여 생성
FROM cte;


select count(*) from users;
select count(*) from posts;


-- 최초 SQL 조회
explain
select p.id, p.title, p.created_at
  from posts p
  join users u on u.id = p.user_id
 where u.name like 'User000004%'
   and p.created_at between '2024-01-01' and '2024-12-31';

-- 인덱스 추가
create index idx_users_name on users(name);
create index idx_posts_created_at on posts(created_at);


explain
select p.id, p.title, p.created_at
  from posts p
  join users u on u.id = p.user_id
 where u.name like 'User000004%'
   and p.created_at between '2024-01-01' and '2024-12-31';



-- 2024년 주문데이터 조회
DROP TABLE IF EXISTS users;
DROP TABLE IF EXISTS orders;

CREATE TABLE users (
   id INT AUTO_INCREMENT PRIMARY KEY,
   name VARCHAR(100),
   created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE orders (
   id INT AUTO_INCREMENT PRIMARY KEY,
   ordered_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
   user_id INT,
   FOREIGN KEY (user_id) REFERENCES users(id)
);

-- 더미데이터 생성
SET SESSION cte_max_recursion_depth = 1000000;

-- users 테이블에 더미 데이터 삽입
INSERT INTO users (name, created_at)
WITH RECURSIVE cte (n) AS
(
 SELECT 1
 UNION ALL
 SELECT n + 1 FROM cte WHERE n < 1000000 -- 생성하고 싶은 더미 데이터의 개수
)
SELECT 
   CONCAT('User', LPAD(n, 7, '0')) AS name,  -- 'User' 다음에 7자리 숫자로 구성된 이름 생성
   TIMESTAMP(DATE_SUB(NOW(), INTERVAL FLOOR(RAND() * 3650) DAY) + INTERVAL FLOOR(RAND() * 86400) SECOND) AS created_at -- 최근 10년 내의 임의의 날짜와 시간 생성
FROM cte;

-- orders 테이블에 더미 데이터 삽입
INSERT INTO orders (ordered_at, user_id)
WITH RECURSIVE cte (n) AS
(
 SELECT 1
 UNION ALL
 SELECT n + 1 FROM cte WHERE n < 1000000 -- 생성하고 싶은 더미 데이터의 개수
)
SELECT 
   TIMESTAMP(DATE_SUB(NOW(), INTERVAL FLOOR(RAND() * 3650) DAY) + INTERVAL FLOOR(RAND() * 86400) SECOND) AS ordered_at, -- 최근 10년 내의 임의의 날짜와 시간 생성
   FLOOR(1 + RAND() * 1000000) AS user_id    -- 1부터 1000000 사이의 난수로 급여 생성
FROM cte;

select count(*) from users;
select count(*) from orders;

-- 기본 쿼리
explain
select *
  from orders
 where YEAR(ordered_at) = 2024
 order by ordered_at
 limit 10000;   -- 0.3s, all type
 
-- 인덱스 생성
create index idx_orders_ordered_at on orders(ordered_at);

-- 재조회
-- explain
select *
  from orders
 where YEAR(ordered_at) = 2024
 order by ordered_at
 limit 10000;   -- 0.3s, all type
 
-- 쿼리 수정
-- explain
select *
  from orders
 where ordered_at >= '2024-01-01 00:00:00'
   and ordered_at < '2025-01-01 00:00:00'
 limit 10000;   -- 0.1s, range type
 



